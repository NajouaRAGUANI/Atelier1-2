'''Atelier2 Exercice3'''
liste=[11, 45 , 8 , 11 , 23 ]
dict={}
for i in range(len(liste)):
    dict[liste[i]] = liste.count(liste[i])

print(dict)