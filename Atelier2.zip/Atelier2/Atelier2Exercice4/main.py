'''Atelier2 Exercice4'''
set11={23, 42, 65, 57, 78, 83, 29}
set12={57, 83, 29, 67, 73, 43, 48}
set13= set11 & set12

for element in set13:
    set11.discard(element)
print( "l intersection des deux sets:", set13)
print("le primier set devient:", set11)
