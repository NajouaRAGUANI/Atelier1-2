'''Atelier2 Exercice2'''
liste0=[ 11, 45 , 8 , 23, 14 , 12 , 78 , 45 , 89]

liste11= liste0[0:3]
liste12=liste0[3:6]
liste13=liste0[6:9]
liste1=liste11[::-1]
liste2=liste12[::-1]
liste3=liste13[::-1]
print(liste1)
print(liste2)
print(liste3)




