'''Atelier2 Exercice1'''
liste11=[3, 6 , 9 , 12 , 15 , 18 , 21]
liste12=[ 4 , 8 , 12 , 16 , 20 , 24 , 28]
liste13=[]
def pairImpair( list1 , list2):

    for i in range(len(list1)):
        if i%2 != 0 :
            liste13.append(list1[i])
    for i in range(len(list2)):
        if i%2 == 0 :
            liste13.append(list2[i])

    return liste13


liste13= pairImpair(liste11 , liste12)
print(liste13)