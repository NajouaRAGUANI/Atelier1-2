'''Atelier2 Exercice5'''

liste=[47, 64, 69, 37, 76, 83, 95, 97]
dict={'Yassine':47, 'Imane':69, 'Mohammed':76, 'Abir':97}
liste2=dict.values()
for element in liste2:
    liste.remove(element)

print(liste2)
print(liste)
