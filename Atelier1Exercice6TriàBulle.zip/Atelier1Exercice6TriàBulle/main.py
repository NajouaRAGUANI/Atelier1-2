'''Atelier1 Exercice6 Tri à Bulle'''
def tri_a_bulle(tab):

    for i in range(len(tab)):
        for j in range(0 , len(tab)-i-1):
            if tab[j] > tab[j+1]:
                tmp = tab[j]
                tab[j]= tab[j+1]
                tab[j+1]=tmp
    return tab
tab=[ 7,3,9,3,1,0]
tab=tri_a_bulle(tab)

for i in range(len(tab)):
    print("%d" %tab[i] , end=' ')


