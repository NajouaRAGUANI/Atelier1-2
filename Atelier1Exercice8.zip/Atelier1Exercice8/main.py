''' Atelier1 Exercice8'''

chaine= str(input(" Enter une chaine:"))
caractere=input("Entrer le caractere à compter son occurence:")
def compter(ch , c):
     nb = 0
     for i in range(len(ch)) :
         if ch[i] == c :
          nb += 1
     return nb

print(" l occurrence de ce caracere est:")

print(compter(chaine , caractere))