'''Atelier1Exercice3'''
nombre=int(input("Enter le nombre de termes:"))
def somme(n):
    if n == 0 :
        return 0
    else :
        return n + somme(n - 1)

print(somme(nombre))