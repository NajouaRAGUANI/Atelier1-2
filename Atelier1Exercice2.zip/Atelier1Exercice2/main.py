''' Atelier1 Exercice2'''
nombre=int(input("Entrer un nombre decimal à convertir en binaire:"))
def decBin(n):
        print(n % 2, end=' ')
        if n > 1:
          return decBin(n//2)


print(" le nombre en binaire est:" )
print(decBin(nombre))