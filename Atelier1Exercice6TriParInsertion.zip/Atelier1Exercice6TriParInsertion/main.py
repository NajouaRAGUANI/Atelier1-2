'''Atelier1 Exercice6 Tri Par Insertion'''
def tri_par_insertion(tab):
    for i in range(1 ,len(tab)):
        tmp = tab[i]
        j = i - 1
        while j >= 0 and tmp < tab[j] :
            tab[j+1] = tab[j]
            j -= 1
            tab[j+1] = tmp
    return tab

tab=[7 ,5 ,3 ,0 ,1]
tab= tri_par_insertion(tab)
for i in range(len(tab)):
    print("%d" %tab[i] , end=' ')