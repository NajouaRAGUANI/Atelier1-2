'''Atelier1 Exercice5'''
nombre=int(input("Entrer un nombre à compter ces chifres:"))
def compter(n):
    cnt=0
    while n!= 0:
        n = int(n/10)
        cnt += 1
    return cnt
print("le nombre des chifres est:" , compter(nombre))
