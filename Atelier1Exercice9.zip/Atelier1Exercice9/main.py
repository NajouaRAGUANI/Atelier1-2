'''Atelier1 Exercice9'''
import array
matrice = [[3, 1, 0] , [2, 9, 8]]
x=int(input("Entrer l elemrnt à chercher:"))
for i in range(len(matrice)):
    for j in range(len(matrice[i])):
        if matrice[i][j]== x :

            print( "<" , i , "," , j , ">")

