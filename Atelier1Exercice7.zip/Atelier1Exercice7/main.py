'''Atelier1 Exercice 7'''
mot=str(input(" Entrer un mot:"))
for i in range (len(mot) - 1 , -1 , -1):
    print(mot[i] , end=' ')