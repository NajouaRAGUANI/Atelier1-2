'''Atelier1 Exercice4'''
nombre=int(input("Enter le nombre de termes :"))

n1 = 0
n2 = 1
print( n1 , "," , n2 , "," , end=' ')
for i in range(nombre - 2):
     suivant = n1 + n2
     print(suivant ,"," , end=' ')
     n1 = n2
     n2 = suivant

