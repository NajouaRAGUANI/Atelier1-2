''' Atelier1 Exercice6 tri par selection'''
#tri par selection
def tri_par_selection(tab):
 for i in range(len(tab)):
    min = i
    for j in range (i+1 , len(tab)):
        if tab[min] > tab[j]:
            min = j
    tmp = tab[i]
    tab[i] = tab[min]
    tab[min] = tmp
 return tab
tab=[1 ,4, 7 ,3 ,2, 0, 8]
tab=tri_par_selection(tab)
for i in range(len(tab)):
    print("%d" %tab[i] , end=' ')

